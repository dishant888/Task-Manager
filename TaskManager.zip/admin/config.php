<?php 
$con=mysqli_connect("localhost","root","","task_manager");
if(!$con)
{
	die("<h1><center>Unable to Connect.....!</h1>");
}
 ?>
